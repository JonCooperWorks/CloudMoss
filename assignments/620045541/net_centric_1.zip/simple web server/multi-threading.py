'''
620041686   
Net Centric Assignment 2
Simple Python HTTP Server-multithread
'''

import socket
import threading

def my_server(connectionSocket, page):
    try:
        f = open(page)
        outputdata = f.read()
        f.close()

        connectionSocket.send( 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: %d\r\n\r\n' % len(outputdata)) 
        connectionSocket.send(outputdata)
        
        for i in range(0, len(outputdata)):
            connectionSocket.send(outputdata[i])    
        connectionSocket.close()

    except IOError:
        f = open('error_message.html')
        error_response = f.read()
        f.close()

        connectionSocket.send('HTTP/1.1 404\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: %d\r\n\r\n' % len (error_response))
        
        connectionSocket.send(error_response)
        connectionSocket.close()


def connection(server_socket):
    connectionsocket, addr = server_socket.accept()
    msg = conn_socket.recv(1024)
    if msg is None:
        return None
    return conn_socket, msg.split()[1][1:]


serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
port = 6759
serverSocket.bind(('', port))
serverSocket.listen(1)

while True:
    print 'Ready to serve...'
    args= connection(serverSocket)
    if argument is None:
        continue
    threading.Thread(target=my_server, args=args).start()
