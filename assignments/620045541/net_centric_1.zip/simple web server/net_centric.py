'''
620041686
Net Centric Computing Assignment 1
A Simple Web Server
'''

#import socket module
from socket import *
serverSocket = socket(AF_INET, SOCK_STREAM)

port = 6759

serverSocket.bind(('',port))
serverSocket.listen(1)


while True:
    print 'Ready to serve...'
    connectionSocket, addr = serverSocket.accept() 
    message = connectionSocket.recv(1024)
    if message == None:
        continue
    filename = message.split()[1][1:]
    try:
        f = open(filename)
        status_code= '200 OK'
        outputdata = f.read()
        f.close()

        connectionSocket.send( 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: %d\r\n\r\n' % len(outputdata)) 
        connectionSocket.send(outputdata)
        
        for i in range(0, len(outputdata)):
            connectionSocket.send(outputdata[i])    
        connectionSocket.close()

    except IOError:
        f = open('error_message.html')
        error_response = f.read()
        f.close()

        connectionSocket.send('HTTP/1.1 404\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: %d\r\n\r\n' % len (error_response))
        
        connectionSocket.send(error_response)
        connectionSocket.close()

    serverSocket.close()

