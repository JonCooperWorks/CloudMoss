
#import socket module
from socket import *
from threading import *


def funct(connectionSocket, outputdata, head):
    connectionSocket.send(outputdata)
    connectionSocket.send(head)
    connectionSocket.close()


serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.bind(('', 9999))

serverSocket.listen(1)
while True:
    #Establish the connection
    print 'Ready to serve...'
    
    connectionSocket, addr = serverSocket.accept() #Fill in start #Fill in end
    try:
        
        message = connectionSocket.recv(10000) #Fill in start #Fill in end
        
        if message == None:
            continue

        filename = message.split()[1]
        f = open(filename[1:])
        outputdata = f.read() #Fill in start #Fill in end
        f.close()
        
        #Send one HTTP header line into socket
        #Fill in start
        #Fill in end
        hed ='HTTP/1.1 200 OK\r\n\r\n'
        t = Thread(target=funct, args=(connectionSocket, outputdata, hed ))
        t.start()
        
    except IOError:
        
        #Send response message for file not found
        #Fill in start
        #Fill in end
        fle = open('errormsg.html')
        error = fle.read()
        fle.close()

        hed = 'HTTP/1.1 404 File not found\r\n\r\n'
        
        t = Thread(target=funct, args=(connectionSocket, error, hed ))
        t.start()
serverSocket.close()
