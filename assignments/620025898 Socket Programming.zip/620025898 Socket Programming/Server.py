#620025898

#import socket module
from socket import *
serverSocket = socket(AF_INET, SOCK_STREAM)

#Prepare a sever socket

#Fill in start
serverPort = 61233
serverSocket.bind(('',serverPort))
serverSocket.listen(1)
#Fill in end

while True:
    
    #Establish the connection
    print 'Ready to serve...'
    
    #Fill in start
    connectionSocket, addr = serverSocket.accept()
    #Fill in end

    try:
        message = connectionSocket.recv(1024)

        #Fill in start
        
        
            
        #Fill in end
        try:
            
            filename = message.split()[1]
        except:
            print 'oh snap, bad request'
            print message
            continue
        
        f = open(filename[1:])
        
        
        #Fill in start
        outputdata = f.read()
        f.close()
        #Fill in end
        
        #Send one HTTP header line into socket

        #Fill in start
        connectionSocket.send('HTTP/1.0 200 OK\r\nContent-Type: text/html\r\n')

        #Fill in end

        #Send the content of the requested file to the client
        for i in range(0, len(outputdata)):
                connectionSocket.send(outputdata[i])
        connectionSocket.close()

    except IOError:
            #Send response message for file not found

            #Fill in start
            print 'File Not Found'
            lost = '''<html> <head> <title> 404 </title> </head> <body><h1>404</h1> <h3> Not Found </h3> </body></html>'''

            #Fill in end
            connectionSocket.send('HTTP/1.0 404\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: %d\r\n\r\n' % len(lost))
            #Close client socket

            #Fill in start
    
            connectionSocket.close()
            #Fill in end
serverSocket.close()
