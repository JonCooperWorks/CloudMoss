#620025898

from threading import *
from socket import *

def serverf(connecSock, data, header):
    connecSock.send(header)
    connecSock.send(data)
    connecSock.close()
    
def mainfunc() :

	serverSocket = socket (AF_INET, SOCK_STREAM)
	serverPort = 61231
	serverSocket.bind(('', serverPort))

	serverSocket.listen(1)
	while True:
		print 'Available to serve'
		connecSock , addr = serverSocket.accept()
		try:
			mess = connecSock.recv(1024)

			if mess == None:
				continue

			filename = mess.split()[1]
			fles = open(filename[1:])

			data = fles.read()
			fles.close()

#			newThread = Thread(target = serverf, args = (connecSock, data, 'HTTP/1.0 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: %d\r\n' % len(data)))
			newThread = Thread(target = serverf, args = (connecSock, data, 'HTTP/1.0 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n'))
			newThread.start()
		except IOError:
			
			 print 'File Not Found'
			 lost = '''<html> <head> <title> 404 </title> </head> <body><h1>404</h1> <h3> Not Found </h3> </body></html>'''

			 #Fill in end
			 #connecSock.send('HTTP/1.0 404\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: %d\r\n\r\n' % len(lost))
			   
			 fles = Thread(target = serverf, args =(connecSock, lost, 'HTTP/1.0 404\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: %d\r\n' % len(lost)))
			 fles.start()
	serverSocket.close()

if __name__ == '__main__' :
	mainfunc()
