
'Id: 620043676'
#import socket module
from socket import *

serverSocket = socket(AF_INET, SOCK_STREAM)

PORT = 2013
serverSocket.bind(('', PORT))

serverSocket.listen(1)
while True:
    #Establishes the connection
    print 'Ready to serve...'

    connectionSocket, addr = serverSocket.accept()
    try:
        
        message = connectionSocket.recv(1024)
        
        if message == None:
            continue

        filename = message.split()[1]
        f = open(filename[1:])
        
        outputdata = f.read()
        f.close()
        #Send one HTTP header line into socket
       
        connectionSocket.send( 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: %d\r\n\r\n' % len(outputdata))
       
        connectionSocket.send(outputdata)
        
        connectionSocket.close()
        
    except IOError:
        #Send response message for file not found
        
        f = open('page404.html')
        response404 = f.read()
        f.close()
       
        #response404= "<!DOCTYPE html><html><head><title> I'm sorry but the page you requestion is not found</title></head></html>"

        connectionSocket.send('HTTP/1.1 404\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: %d\r\n\r\n' % len(response404))
        connectionSocket.send(response404)
        #Close client socket
        connectionSocket.close()
serverSocket.close()
